# Brief for Claude Code — Plan-view door-swing symbol, zoom-quality fix

Written 22 Sep 2026. Standalone piece of work, separate from the doors/colour/grain session (that one
is done, verified, pushed). Work from the repo (`C:\Dev\CupboardApp`, branch `master`), never the
OneDrive copy.

Three reference images are provided alongside this brief in `reference/`:
- `plan-view-door-swing-reference.png` — Rudolf's reference for the door-swing convention wanted in
  Plan view (from other CAD software he uses). **Look at this directly before building** — it's more
  reliable than any text description of it.
- `zoom-distortion-zoomed-out.png` / `zoom-distortion-zoomed-in.png` — the same wall at two zoom
  levels, showing lines and text thickening/distorting as zoom increases.

---------------------------------------------------------------------------------------------------

## 0. How to work

1. **One todo per ID.** Mark done only after exercising it live in the running app, not after writing
   the code.
2. **Section 2 (diagnose) before Section 3 (build)** — what's found changes how much building is
   actually needed.
3. **Ask, don't guess** on anything not covered here that turns out to be a real judgment call.
4. `git pull` at the start, `git push` at the clean stop (branch `master`, not `main`).
5. **Never run `git checkout` or any command that discards Rudolf's uncommitted changes without
   asking first.**
6. Rudolf's style: concise, plain English, correct technical terms. Report in that style.

---------------------------------------------------------------------------------------------------

## 1. What's asked

1. **Plan view must show doors and drawer fronts as a proper swing/opening symbol**, not just an
   outline that happens to include the door's depth. See `reference/plan-view-door-swing-reference.png`
   for the convention wanted. It must be **parametric** — driven by each cabinet's real hinge side,
   opening width, and geometry (hard rule 1 applies as everywhere: never from a declared dimension).
2. **Zoom rendering quality, both Wall and Plan views**: lines and text must stay visually consistent
   at any zoom level. Right now they thicken/distort as you zoom in — see the two comparison images.

---------------------------------------------------------------------------------------------------

## 2. Diagnose first, report, then build

- **P1 — Does `room.swing_envelopes` already cover this?** It was built 15 Sept for corner-unit
  clearance checking, computing swing geometry off the real hinge face. Check whether it (or something
  equivalent) already computes swing geometry for **ordinary cabinets**, not just corner units. If so,
  this symbol may be "draw what's already computed" rather than "derive new geometry" — report which,
  same pattern as the board-picture work turning out to already be read but never drawn.
- **P2 — Why do lines/text distort on zoom?** Find the current zoom mechanism (CSS transform on the
  SVG container, a `viewBox` rescale, explicit scale on individual elements, something else) in both
  the Wall and Plan view code. Report what it actually is before proposing a fix — the right fix
  depends on the mechanism.

---------------------------------------------------------------------------------------------------

## 3. Build

- **Plan-view door-swing symbol.** For every door and drawer front, draw a swing/opening indicator in
  Plan view matching the convention in the reference image — hinge point, leaf, and swing shown in the
  open position (that's the point of a plan-view swing symbol: showing the clearance it needs). Use
  `swing_envelopes` if `P1` confirms it's usable for ordinary cabinets; otherwise compute fresh from
  each door's real hinge side and opening width, the same way the rest of the app already derives
  geometry from `room.geometry(cab)`, never from declared dimensions.
- **Zoom-quality fix, Wall and Plan.** Keep stroke-width and text size constant in screen pixels
  regardless of zoom level — typically `vector-effect="non-scaling-stroke"` on strokes plus
  recalculating font-size relative to the current zoom factor, but base the actual fix on what `P2`
  finds rather than assuming this is the mechanism in use here.

---------------------------------------------------------------------------------------------------

## 4. Explicitly out of scope

- Freestanding/island cabinet placement.
- Anything 3D (Phase 6).
- Any change to gap/filler/scribe/plinth logic, or corner-unit logic.
- The plan-view drag-sticks-to-pointer bug (known open item, separate fix, untouched here).
- Anything already finished in the doors/colour/grain session — board texture, colour priority, grain
  validation, top dimension line. Don't touch that code beyond what `P1`/`P2` need to read.

---------------------------------------------------------------------------------------------------

## 5. Verification protocol

1. `python tools/regen_check.py` — **272 MEL / 59 BROOKHILL / 30 BACK, 92 pot holes, 18/9/6 boards,
   ~R28,363.50.** This is drawing-only work; benchmark shouldn't move.
2. Every `tools/check_*.py` passes.
3. `python tools/snapshot.py --compare baseline.json --allow svg` — only drawings should differ.
4. `Check It Still Works.bat`.
5. **Drive the real UI**: Plan view shows correct swing symbols for doors on a range of hinge sides and
   widths, including at least one drawer front and one cabinet with no door (open shelving — should show
   nothing); zoom in and out on both Wall and Plan views and confirm lines/text stay crisp at every
   level, matching the "zoomed out" reference rather than the "zoomed in" one. Screenshot each. Report
   **per ID: pass / fail / not tested.**

## 6. Docs to update (at the clean stop)

- `CLAUDE.md`: Status, resolved open items.
- Save a short summary of the stop as a doc in the Project (`Claude outputs/…`).
